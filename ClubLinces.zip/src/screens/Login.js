import { 
    View, 
    Text, 
    TextInput, 
    Button 
} from 'react-native';

import { 
    useState,
    useContext
} from 'react';


import {
    loginUsuario
} from '../services/usuarioService';


import {
    guardarSesion
} from '../services/sesionService';

import { SessionContext } from '../context/SessionContext';



export default function Login({navigation}){

    const { iniciarSesionApp } = useContext(SessionContext);

    const [correo,setCorreo] = useState("");

    const [password,setPassword] = useState("");




    async function iniciarSesion(){


        const resultado = loginUsuario(

            correo,

            password

        );




        if(resultado.correcto){



            await guardarSesion(

                resultado.usuario

            );



            iniciarSesionApp(

                resultado.usuario

            );


        }

        else{


            console.log(

                resultado.mensaje

            );


        }


    }





    return(

        <View>


            <Text>

                CLUB LINCES

            </Text>





            <TextInput

                placeholder="Correo"

                value={correo}

                onChangeText={setCorreo}

            />





            <TextInput

                placeholder="Contraseña"

                value={password}

                secureTextEntry={true}

                onChangeText={setPassword}

            />





            <Button

                title="Ingresar"

                onPress={iniciarSesion}

            />





            <Button

                title="Crear cuenta entrenador"

                onPress={()=>


                    navigation.navigate(

                        "Registro"

                    )


                }

            />


        </View>


    );


}