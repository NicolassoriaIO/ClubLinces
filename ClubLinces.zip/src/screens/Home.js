import { 
    View, 
    Button 
} from 'react-native';

import { useContext } from 'react';

import { SessionContext } from '../context/SessionContext';


export default function Home({navigation}){

    const { cerrarSesionApp } = useContext(SessionContext);


    function cerrarSesion(){

        cerrarSesionApp();

    }



    return(

        <View>


            <Button

                title="Ver atletas"

                onPress={() => 
                    navigation.navigate('Atletas')
                }

            />



            <Button

                title="Agenda"

                onPress={() => 
                    navigation.navigate('Agenda')
                }

            />



            <Button

                title="Cerrar sesión"

                onPress={cerrarSesion}

            />


        </View>

    );

}